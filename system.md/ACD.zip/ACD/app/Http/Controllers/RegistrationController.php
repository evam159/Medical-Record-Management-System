<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Registration;
use App\Models\Record;

class RegistrationController extends Controller
{
    public function index()
    {
        $registrations = Registration::all();
        return view("pages.home")->with("registrations", $registrations);
    }

    
    public function create()
    {
        return view("pages.add_home");
    }

   
    public function store(Request $request)
    {
        $registration = new Registration();

        $registration->lastname = $request->lname_input;
        $registration->firstname = $request->fname_input;
        $registration->year_level = $request->year_level;
        $registration->age = $request->age_input;
        $registration->birthday = $request->bday;
        $registration->sex = $request->sex;
        $registration->course = $request->course;

        $registration->save();

        return redirect()->route('registrations.index');

    }

  
    public function show($id)
    {
        // 
    }

   
    public function edit($id)
    {
        $registration = Registration::find($id);
        return view("pages.edit_home")->with("registration",$registration);
    }

   
    public function update(Request $request, $id)
    {
        $registration= Registration::find($id);

        $registration->lastname = $request->lname_input;
        $registration->firstname = $request->fname_input;
        $registration->year_level = $request->year_level;
        $registration->age = $request->age_input;
        $registration->birthday = $request->bday;
        $registration->sex = $request->sex;
        $registration->course = $request->course;

        $registration->save();

        return redirect()->route('registrations.index');
    }

   
    public function destroy($id)
    {
        $registration=Registration::find($id);
        $registration->delete();
        return redirect()->route('registrations.index');
    }
}
