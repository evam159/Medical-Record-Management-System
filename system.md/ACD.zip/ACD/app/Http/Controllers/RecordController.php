<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Record;
use App\Models\Registration;


class RecordController extends Controller
{
    
    public function index()
    {
        $registrations =  Registration::all();
        
        return view("pages.record")->with("registrations", $registrations);
        
    }

    
    public function create()
    {
         return view("pages.add_record");
    }

    
    public function store(Request $request)
    {
        $registration=new Registration();

        $record = new Record();

        $registration->$record = $request->lastname;
        $record->school_year= $request->sy;
        $record->weight = $request->w;
        $record->height = $request->h;
        $record->complains = $request->complains;
        $record->diagnostic = $request->diagnostic;
        $record->treatment = $request->treatment;
        $record->doctor = $request->doc;
        $record->nurse = $request->nurse;
        $record->status = $request->status;
        $record->time = $request->time;
        $record->date_of_complains = $request->date;


        $record->save();

        return redirect()->route('records.index');
    }

    
    public function show($id)
    {
        $record=Record::find($id);
        $registration=Registration::find($id);

    
       
        if ($record->$id == $registration->id){
            return redirect("pages.view_empty_rec")->with("record", $record);
             }
        else{
            return view('pages.view_rec')->with("record", $record);
        }

        // if ($record->$id == $registration->id){
        //    return view("pages.view_empty_rec")->with("record", $record);
        // }
        // elseif($record->$id->isEmpty){
        //     return view("pages.view_rec")->with("record", $record);
        // }
        
        
    }
    
    


    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        //
    }

    
    public function destroy($id)
    {
        //
    }
}
