<?php

namespace App\Http\Controllers;

use App\Models\Nurse;
use Illuminate\Http\Request;

class NurseController extends Controller
{

    public function index()
    {
        $nurses =  Nurse::all();
        return view("pages.nurse")->with("nurses", $nurses);
    }
    public function create()
    {
        return view("pages.add_nurse");
    }

    public function store(Request $request)
    {
        $nurse = new Nurse();

        $nurse->id_num = $request->id_no;
        $nurse->lastname = $request->lastname;
        $nurse->firstname = $request->firstname;
        $nurse->sex = $request->sex;
        

        $nurse->save();

        return redirect()->route('nurses.index');
    }

    public function show($id)
    {
        $nurse=Nurse::find($id);
        return view("pages.view_nurse")->with("nurse", $nurse);
    }
    public function edit($id)
    {
         $nurse=Nurse::find($id);
        return view("pages.edit_nurse")->with("nurse", $nurse);
    }
    public function update(Request $request, $id)
    {
        $nurse= Nurse::find($id);

        $nurse->id_num = $request->id_no;
        $nurse->lastname = $request->lastname;
        $nurse->firstname = $request->firstname;
        $nurse->sex = $request->sex;

        $nurse->save();

        return redirect()->route('nurses.index');
    }
    public function destroy($id)
    {
        $nurse=Nurse::find($id);
        $nurse->delete();
        return redirect()->route('nurses.index');
    }
}
