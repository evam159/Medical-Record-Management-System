<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use Illuminate\Http\Request;

class DoctorController extends Controller
{

    public function index()
    {
        $doctors =  Doctor::all();
        return view("pages.doctor")->with("doctors", $doctors);
    }
    public function create()
    {
        return view("pages.add_doctor");
    }
    public function store(Request $request)
    {
        $doctor = new Doctor();

        $doctor->lic_id_num = $request->lic_id_no;
        $doctor->lastname = $request->lastname;
        $doctor->firstname = $request->firstname;
        $doctor->sex = $request->sex;
        $doctor->specialization = $request->specialization;
        

        $doctor->save();

        return redirect()->route('doctors.index');
    }
    public function show($id)
    {
        $doctor=Doctor::find($id);
        return view("pages.view_doc")->with("doctor", $doctor);
    }
    public function edit($id)
    {
        $doctor = Doctor::find($id);
        return view("pages.edit_doctor")->with("doctor",$doctor);
    }
    public function update(Request $request, $id)
    {
        $doctor= Doctor::find($id);

        $doctor->lic_id_num = $request->lic_id_no;
        $doctor->lastname = $request->lastname;
        $doctor->firstname = $request->firstname;
        $doctor->sex = $request->sex;
        $doctor->specialization = $request->specialization;

        $doctor->save();

        return redirect()->route('doctors.index');
    }

    public function destroy($id)
    {
        $doctor=Doctor::find($id);
        $doctor->delete();
        return redirect()->route('doctors.index');
    }
}
