

<?php $__env->startSection('title'); ?>
    Edit Doctors
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container border border-dark mt-5">
    <div class="container mt-5">

            <h5><b>Edit Doctors</b></h5>

                <form action="<?php echo e(route('update', $doctor->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-7 offset-md-3 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 40rem">
                                <div class="card-body center">

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>License id num.</b></label required>
                                        <input type="text" value="<?php echo e($doctor->lic_id_num); ?>" class="form-control" name ="lic_id_no">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Last Name</b></label required>
                                        <input type="text" value="<?php echo e($doctor->lastname); ?>" class="form-control" name ="lastname">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>First Name</b></label required>
                                        <input type="text" value="<?php echo e($doctor->firstname); ?>" class="form-control" name ="firstname">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Sex</b></label required><br>
                                        <input type="radio" value="<?php echo e($doctor->sex); ?>"  class="form-control">
                                        <input type="radio" name="sex" value="male"> Male<br>
                                        <input type="radio" name="sex" value="female"> Female<br>   
                                    </div>

                                        <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                            <label class="form-group mb-4"><b>Specialzation</b></label required>
                                            <select class="form-select" value="<?php echo e($doctor->course); ?>" aria-label="Default select example" class="form-control" name ="specialization">
                                                
                                                <option value="Ophthalmologist">Ophthalmologist</option>
                                                <option value="Psychiatric">Psychiatric</option>
                                                <option value="Internal Medicine">Internal Medicine</option>
                                                <option value="Endodontist">Endodontist</option>
                                            </select> 
                                        </div>

                                        <div class="pt-4">
                                            <div class="row">
                                                <div class="col-md-3 offset-md-3">
                                                    <input type="submit" value="Update" class="btn btn-success">
                                                </div>
                                                <div class="col-md-5">
                                                    <a href="<?php echo e(route('doctor-page')); ?>" id="cancel" class="btn btn-primary">Cancel</a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                        
                </div>
            
        </div>         
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Project\ACD\resources\views/doc_pages/edit_doc.blade.php ENDPATH**/ ?>