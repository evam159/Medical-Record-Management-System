<div class="footer">
    
    <div>© Copyright 2021 Assumption College of Davao </div>
    
</div><?php /**PATH E:\Laravel\Project\ACD\resources\views/share/footer.blade.php ENDPATH**/ ?>