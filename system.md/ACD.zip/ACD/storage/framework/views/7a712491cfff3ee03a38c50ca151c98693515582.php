

<?php $__env->startSection('title'); ?>
    Log In
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="pt-5">
        <div class="row">
            <div class="card border-dark col-md-4 offset-md-4 mt-6"><center>
                <h3 class="card border-light bg-light">ACD Clinic Admin</h3>
                <img src="images/acd.png" width=" 220px" height="200 px"></a>	</center>
                <div class="card border-light bg-light pt-4" style="width: 15 rem;">      

                <form action="<?php echo e(route('login')); ?>" method="post">
                    <div class="form-group col-md-7 offset-md-2 pt-4">
                        Username <input type="text" name="username" id="" class="form-control">
                    </div>

                    <div class="form-group col-md-7 offset-md-2 mt-3">
                        Password <input type="password" name="password" id="" class="form-control">
                    </div>
                    <div class="form-group col-md-7 offset-md-2 mt-3">
                        <input type="submit" value="Login " class="btn btn-primary mt-2 form-control ">
                    </div>
                    <div class="form-group col-md-7 offset-md-1 mt-3"></div>
                    
                	    <?php echo csrf_field(); ?>
                </form>
                <?php if($errors->any()): ?>
                   <div class="alert alert-danger" role="alert">
                        <?php echo e($errors->first()); ?>

                    </div>
                 <?php endif; ?>
           
                
            </div>
            <div class="form-group col-md-7 offset-md-1 mt-3"></div>
        </div>
     </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('document').ready(function(){
        <?php if($errors->any()): ?>
        $(".alert").fadeIn(500).delay(3000).fadeOut(500);   
        <?php endif; ?> 
    })
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Project\ACD\resources\views/pages/login.blade.php ENDPATH**/ ?>