

<?php $__env->startSection('title'); ?>
    Home   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
            <ul class="navbar justify-content-end navbar navbar-expand-lg navbar-dark bg-dark">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('main-page')); ?>">Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">Doctors</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">Nurses</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">Medical Records</a>
                </li>       
            </ul>
    <div class="container">
        <div class="pt-5">
            <div class="row">
                <div class="image_acd col-md-4 mt-6">
                    <img src="images/acd.png" width=" 300px" height="280 px"></a>	
                </div>
                    <div class="col-md-6 mt-4">
                        <h1 class=" nav justify-content-center">Assumption College of Davao </h1><br>
                        <h5 class=" nav justify-content-center">J.P. Cabaguio Avenue Davao City</h5><br>
                        <h5 class=" nav justify-content-center">Tel. No. 225 07 20 to 23</h5><br>
                        <h5 class=" nav justify-content-center">www.assumptiondavao.edu.ph</h5><br><br>
                        <h3 class=" nav justify-content-center">Clinic Medical Records</h3><br>
                    </div>
                </div>
            </div>
        </div>
            <div class="container">

                <div class="col-md-12 ">
                   
                    
                
                    <div class="pt-4">
                        <div class="row">
                            <ul class="nav justify-content-end" id="reg">
                                <li class="nav-item">
                                <a class="nav-link active btn btn-primary" aria-current="page" href="<?php echo e(route('add_home')); ?>">Register</a>
                                </li>
                            </ul>
                       

                            <h3 class="btn btn-secondary mt-3">College Students </h3>

                </div>
            </div>

        
                    <table class="table mt-2">
                        <thead>
                            <tr>
                                
                                <td><b>ID</b></td>
                                <td><b>Last Name</b></td>
                                <td><b>First Name</b></td>
                                <td><b>Year Level</b></td>
                                <td><b>Age</b></td>
                                <td><b>Birthday</b></td>
                                <td><b>Sex</b></td>
                                <td><b>Course</b></td>
                                <td><b>Edit</b></td>
                                <td><b>Delete</b></td>
                               
                                
                            </tr> 
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($registration->id); ?></td>
                                <td><?php echo e($registration->lastname); ?></td> 
                                <td><?php echo e($registration->firstname); ?></td> 
                                <td><?php echo e($registration->year_level); ?></td> 
                                <td><?php echo e($registration->age); ?></td> 
                                <td><?php echo e($registration->birthday); ?></td> 
                                <td><?php echo e($registration->sex); ?></td> 
                                <td><?php echo e($registration->course); ?></td> 
                               
                                
    
                                </td>
                                <div class="image pt-6">
                                    <td><a href="<?php echo e(route('edit', $registration->id)); ?>"><center><img src="images/edit2.png" width=" 30px" height="20 px"></center></a></td>
                                </div>
                                
                                <td><a href="<?php echo e(route('destroy', $registration->id)); ?>" onclick="return confirm('Are you sure to remove this file?');"><center><img src="images/del.png" width=" 20px" height="20 px"></center></a></td>
                              
                            </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <a href="#" class=" nav-link active btn btn-secondary justify-content-end ">Back to top</a></a>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Project\ACD\resources\views/home_pages/home.blade.php ENDPATH**/ ?>