

<?php $__env->startSection('title'); ?>
    Medical Records
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container border border-dark bg-light mt-4 pt-4">
        <nav class="navbar-light">
            <div class="container">
                
        </nav>
    </div>
                <div class="container border border-dark bg-info">
                    <div class="col-md-5 offset-md-2 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 50rem">
                                <div class="card-body">
                                    <div class="col-md-7 offset-md-1 mt-3">
                                        <h5><b>Student Medical Record Details</b><h5> 
                                            
                                            <div class="col-md-7 offset-md-4 pt-5">
                                                <h6><b>School Year : </b><?php echo e($record->school_year); ?> </h6><br>
                                                <h6><b>Weight :</b><?php echo e($record->weight); ?></h6><br>
                                                <h6><b>Height : </b><?php echo e($record->height); ?></h6><br>                                      
                                                <h6><b>Complains : </b><?php echo e($record->complains); ?></h6><br>                                     
                                                <h6><b>Diagnostic : </b><?php echo e($record->diagnostic); ?></h6><br>                                       
                                                <h6><b>Treatment : </b><?php echo e($record->treatment); ?></h6><br>                                     
                                                <h6><b>Doctor : </b><?php echo e($record->doctor); ?></h6><br>                                       
                                                <h6><b>Nurse : </b><?php echo e($record->nurse); ?></h6><br>                                       
                                                <h6><b>Status : </b><?php echo e($record->status); ?></h6><br>                                       
                                                <h6><b>Time : </b><?php echo e($record->time); ?></h6><br>                                       
                                                <h6><b>Date of Complains : </b><?php echo e($record->date_of_complains); ?></h6>                                       
                                            </div>
                                            

                                            <div class="pt-4">                                          
                                                <div class="col-md-3 offset-md-7">
                                                    <a href="<?php echo e(route('records.index')); ?>" class="mt-2 btn btn-info">Back</a>
                                                </div>
                                            </div>
                                    </div>
                                    
                            </div>                            
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Project\ACD\resources\views/pages/view_rec.blade.php ENDPATH**/ ?>