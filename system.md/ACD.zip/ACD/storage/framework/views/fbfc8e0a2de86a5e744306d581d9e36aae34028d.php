

<?php $__env->startSection('title'); ?>
    Edit Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container border border-dark mt-5">
    <div class="container mt-5">
        
            <h5><b>Edit Registration</b></h5>

                <form action="<?php echo e(route('registrations.update', $registration->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>

                    <div class="col-md-7 offset-md-3 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 40rem">
                                <div class="card-body center">

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Last Name</b></label required>
                                        <input type="text" value="<?php echo e($registration->lastname); ?>" class="form-control" name ="lname_input">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>First Name</b></label required>
                                        <input type="text" value="<?php echo e($registration->firstname); ?>" class="form-control" name ="fname_input">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Year Level</b></label required>
                                        <select class="form-select" value="<?php echo e($registration->year_level); ?>" aria-label="Default select example" class="form-control" name ="year_level">
                                            
                                            <option value="fourth year">fourth year</option>
                                            <option value="third year">third year</option>
                                            <option value="second year">second year</option>
                                            <option value="first year">first year</option>
                                        </select> 
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Age</b></label required>
                                        <input type="number" value="<?php echo e($registration->age); ?>"  class="form-control" name ="age_input">
                                    </div>

                                        <div class="col-md-7 offset-md-1 mt-3" style="width: 18 rem">
                                            <label class="form-label fw-bold"><b>Birthday</b></label required>
                                            <input type="date" value="<?php echo e($registration->birthday); ?>" class="form-control" name="bday">
                                        </div>
                                        
                                        <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                            <label class="form-group mb-4"><b>Sex</b></label required><br>
                                            <input type="radio" value="<?php echo e($registration->sex); ?>"  class="form-control">
                                            <input type="radio" name="sex" value="male"> Male<br>
                                            <input type="radio" name="sex" value="female"> Female<br>
                                            
                                            
                                        </div>

                                        <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                            <label class="form-group mb-4"><b>Course</b></label required>
                                            <select class="form-select" value="<?php echo e($registration->course); ?>" aria-label="Default select example" class="form-control" name ="course">
                                                
                                                <option value="BSIT">BSIT</option>
                                                <option value="BSHM">BSHM</option>
                                                <option value="BEED">BEED</option>
                                                <option value="BSED">BSED</option>
                                                <option value="BSHM">BSHM</option>
                                            </select> 
                                        </div>

                                        <div class="pt-4">
                                            <div class="row">
                                                <div class="col-md-3 offset-md-3">
                                                    <input type="submit" value="Update" class="btn btn-success">
                                                </div>
                                                <div class="col-md-5">
                                                    <a href="<?php echo e(route('registrations.index')); ?>" id="cancel" class="btn btn-primary">Cancel</a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pt-5"></div>                    
                </div>
            
        </div>         
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Project\ACD\resources\views/pages/edit_home.blade.php ENDPATH**/ ?>