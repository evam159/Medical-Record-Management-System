<div class="footer">
    
    <div>© Copyright 2021 Assumption College of Davao </div>
    
</div>