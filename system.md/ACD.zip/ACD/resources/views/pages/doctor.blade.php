@extends('layouts.master')

@section('title')
    Doctors   
@endsection
@section('content')
    <ul class="navbar justify-content-end navbar navbar-expand-lg navbar-dark bg-dark">
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="{{route('registrations.index')}}">Home</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="{{route('doctors.index')}}">Doctors</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="{{route('nurses.index')}}">Nurses</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="{{route('records.index')}}">Medical Records</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="{{route('/logout')}}">Log Out</a>
        </li>        
    </ul>

    <div class="container">
        <div class="pt-5">
            <div class="row">
                <div class="image_acd col-md-4 mt-6">
                    <img src="images/acd.png" width=" 300px" height="280 px"></a>	
                </div>
                    <div class="col-md-6 mt-4">
                        <h1 class=" nav justify-content-center">Assumption College of Davao </h1><br>
                        <h5 class=" nav justify-content-center">J.P. Cabaguio Avenue Davao City</h5><br>
                        <h5 class=" nav justify-content-center">Tel. No. 225 07 20 to 23</h5><br>
                        <h5 class=" nav justify-content-center">www.assumptiondavao.edu.ph</h5><br><br>
                        <h3 class=" nav justify-content-center">Clinic Medical Records</h3><br>
                    </div>
                </div>
            </div>
        </div>

    <div class="container">
        <div class="col-md-12 ">
            <div class="pt-4">
                <div class="row">
                    <ul class="nav justify-content-end" id="reg">
                        <li class="nav-item">
                        <a class="nav-link active btn btn-primary" aria-current="page" href="{{route('doctors.create')}}">Register</a>
                        </li>
                    </ul>
                    <h3 class="btn btn-secondary mt-3">Doctors</h3>
                </div>
        </div>
    </div>

    <div class="container ">
        <div class="row ">
            @foreach ($doctors as $doctor)
                <div class="col-md-4  pt-5">
                    <div class="card border-dark bg-light" style="width: 15 rem;">         
                        <div class="card-body text-secondary">
                            <div> 
                                <div class="col-md-7 offset-md-10">
                                    <div style="position: relative">
                                            <a href="#" onclick="return confirm('Delete {{$doctor->lastname}} {{$doctor->firstname}}?');">
                                                <form action="{{route('doctors.destroy', $doctor->id)}}" method="post">
                                                    @method('DELETE')
                                                    @csrf
                                                    <button type=submit class= "btn btn-danger"><img src="images/del.png" width=" 25px" height="20 px"></a></button>
                                                </form> 
                                            </a>
                                        
                                    </div>
                                </div>

                                        
                                <div>									
                                    <div class="card-title  pt-2 ">
                                        <center>
                                        <span class="btn btn-success"><b>{{$doctor->firstname}} {{$doctor->lastname}}</b></span><br>
                                        <span class="btn btn-light">Licence Id No. <b>{{$doctor->lic_id_num}}</b></span><br></center>
                                            <center>
                                                <div class="pt-4">
                                                    <a href="{{route('doctors.show', $doctor->id)}}" class=" btn btn-success  "><img src="images/view.png" width=" 25px" height="20 px">View</a>	
                                                    <a href="{{route('doctors.edit', $doctor->id)}}" class=" btn btn-warning  "><img src="images/edit3.png" width=" 25px" height="20 px">Edit</a>																		
                                                </div>
                                            </center>
                                    </div>																	
                                </div>											
                            </div>														
                        </div>
                    </div>
                </div>
            @endforeach	
        </div>
    </div>



@endsection