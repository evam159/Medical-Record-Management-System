@extends('layouts.master')

@section('title')
    Record Register
@endsection

@section('content')

<div class="container border border-dark mt-5 pt-4">
    <div class="container">

            <nav class="navbar-light">
	            <span class="navbar-brand mb-0 h1"><b>New Medical Record</b></span>   
            </nav>
    </div>
        
            <form action="{{route('records.store')}}" method="post">
                @csrf
                @method('post')
                    <div class="col-md-7 offset-md-3 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 40rem;">
                                <div class="card-body center">
                                   

                                    
                                   
                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Weight</b></label required>
                                        <input type="text" class="form-control" name ="h">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Height</b></label required>
                                        <input type="text" class="form-control" name ="w">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Complains</b></label required>
                                        <input type="text" class="form-control" name ="complains">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Diagnostic</b></label required>
                                        <input type="text" class="form-control" name ="diagnostic">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Treatment</b></label required>
                                        <input type="text" class="form-control" name ="treatment">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Doctor</b></label required>
                                        <select class="form-select" aria-label="Default select example" class="form-control" name ="specialization">
                                            <option selected>--Select Doctors--</option>
                                            <option value="Kim Chua">Kim Chua</option>
                                            <option value="Fernando Pacatang">Fernando Pacatang</option>
                                            <option value="Carmelita Suarez">Carmelita Suarez</option>
                                            <option value="Cazzerie Gonzales">Cazzerie Gonzales</option>
                                        </select> 
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Nurse</b></label required>
                                        <select class="form-select" aria-label="Default select example" class="form-control" name ="specialization">
                                            <option selected>--Select Nurses--</option>
                                            <option value="Hanabeth Pastor Orcullo">Hanabeth Pastor Orcullo</option>
                                            <option value="Emei Eltagonde">Emei Eltagonde</option>
                                            <option value="Michael Ryan Bituan">Michael Ryan Bituan</option>
                                            <option value="Rhea Reyes">Rhea Reyes</option>
                                        </select> 
                                    </div>

    

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Time</b></label required>
                                        <input type="time" class="form-control" name ="time">
                                    </div><br>

                                        <div class="col-md-7 offset-md-1 mt-3" style="width: 18 rem">
                                            <label class="form-label fw-bold"><b>Date of Complains</b></label required>
                                            <input type="date" class="form-control" name="date">
                                        </div><br>
                                        
                                        

                                    <div class="pt-4">
                                        <div class="row">
                                            <div class=" col-md-3 offset-md-3">
                                                <input type="submit" value="Create" class="btn btn-success">
                                            </div>
                                                <div class=" col-md-5">
                                                    <a href="{{route('records.index')}}" id="cancel" name="cancel" class="btn btn-primary">Cancel</a>
                                                   
                                            	</div>
                                        </div>
                                    </div>            
                                </div>

                            </div> 
                            
                        </div>   
                        <div class="pt-5"></div>   
                    </div>
            </form>
    </div>
</div>
</div>        

@endsection
