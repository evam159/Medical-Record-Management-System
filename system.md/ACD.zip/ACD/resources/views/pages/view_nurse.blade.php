@extends('layouts.master')

@section('title')
    Nurse Details
@endsection
@section('content')
    <div class="container border border-dark bg-light mt-4 pt-4">
        <nav class="navbar-light">
            <div class="container">
                <span class="navbar-brand mb-0 h1"><b>{{$nurse->firstname}} {{$nurse->lastname}}</b></span>
            </div>
        </nav>
    </div>
                <div class="container border border-dark bg-info">
                    <div class="col-md-5 offset-md-2 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 50rem">
                                <div class="card-body">
                                    <div class="col-md-7 offset-md-1 mt-3">
                                        <h5><b>Details</b><h5> 
                                            <div class="col-md-7 offset-md-5 pt-5">
                                                <h6><b>Id No: </b>{{ $nurse->id_num }} </h6><br>
                                                <h6><b>Name: </b>{{ $nurse->firstname }} {{ $nurse->lastname }}</h6><br>
                                                <h6><b>Sex: </b>{{ $nurse->sex }}</h6>                                
                                            </div>

                                            <div class="pt-4">                                          
                                                <div class="col-md-3 offset-md-7">
                                                    <a href="{{ route('nurses.index') }}" class="mt-2 btn btn-info">Back</a>
                                                </div>
                                            </div>
                                    </div>
                            </div>                            
                        </div>
                    </div>
                </div>

@endsection