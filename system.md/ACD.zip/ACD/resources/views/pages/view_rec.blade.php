@extends('layouts.master')

@section('title')
    Medical Records
@endsection
@section('content')
    <div class="container border border-dark bg-light mt-4 pt-4">
        <nav class="navbar-light">
            <div class="container">
                {{-- <span class="navbar-brand mb-0 h1"><b>{{$registration->firstname}} {{$registration->lastname}}</b></span>
            </div> --}}
        </nav>
    </div>
                <div class="container border border-dark bg-info">
                    <div class="col-md-5 offset-md-2 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 50rem">
                                <div class="card-body">
                                    <div class="col-md-7 offset-md-1 mt-3">
                                        <h5><b>Student Medical Record Details</b><h5> 
                                            
                                            <div class="col-md-7 offset-md-4 pt-5">
                                                <h6><b>School Year : </b>{{ $record->school_year }} </h6><br>
                                                <h6><b>Weight :</b>{{ $record->weight }}</h6><br>
                                                <h6><b>Height : </b>{{ $record->height }}</h6><br>                                      
                                                <h6><b>Complains : </b>{{ $record->complains }}</h6><br>                                     
                                                <h6><b>Diagnostic : </b>{{ $record->diagnostic }}</h6><br>                                       
                                                <h6><b>Treatment : </b>{{ $record->treatment }}</h6><br>                                     
                                                <h6><b>Doctor : </b>{{ $record->doctor }}</h6><br>                                       
                                                <h6><b>Nurse : </b>{{ $record->nurse }}</h6><br>                                       
                                                <h6><b>Status : </b>{{ $record->status }}</h6><br>                                       
                                                <h6><b>Time : </b>{{ $record->time }}</h6><br>                                       
                                                <h6><b>Date of Complains : </b>{{ $record->date_of_complains }}</h6>                                       
                                            </div>
                                            

                                            <div class="pt-4">                                          
                                                <div class="col-md-3 offset-md-7">
                                                    <a href="{{ route('records.index') }}" class="mt-2 btn btn-info">Back</a>
                                                </div>
                                            </div>
                                    </div>
                                    
                            </div>                            
                        </div>
                    </div>
                </div>

@endsection