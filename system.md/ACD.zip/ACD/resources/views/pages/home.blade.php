@extends('layouts.master')

@section('title')
    Home   
@endsection
@section('content')
            <ul class="navbar justify-content-end navbar navbar-expand-lg navbar-dark bg-dark">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="{{route('registrations.index')}}">Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="{{route('doctors.index')}}">Doctors</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="{{route('nurses.index')}}">Nurses</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="{{route('records.index')}}">Medical Records</a>
                </li>       
                <li class="nav-item">
                <a class="nav-link" href="{{route('/logout')}}">Log Out</a>
                </li>  
            </ul>
    <div class="container">
        <div class="pt-5">
            <div class="row">
                <div class="image_acd col-md-4 mt-6">
                    <img src="images/acd.png" width=" 300px" height="280 px"></a>	
                </div>
                    <div class="col-md-6 mt-4">
                        <h1 class=" nav justify-content-center">Assumption College of Davao </h1><br>
                        <h5 class=" nav justify-content-center">J.P. Cabaguio Avenue Davao City</h5><br>
                        <h5 class=" nav justify-content-center">Tel. No. 225 07 20 to 23</h5><br>
                        <h5 class=" nav justify-content-center">www.assumptiondavao.edu.ph</h5><br><br>
                        <h3 class=" nav justify-content-center">Clinic Medical Records</h3><br>
                    </div>
                </div>
            </div>
        </div>
            <div class="container">

                <div class="col-md-12 ">
                   
                    {{-- <a href="{{route('add')}}"></a> --}}
                
                    <div class="pt-4">
                        <div class="row">
                            <ul class="nav justify-content-end" id="reg">
                                <li class="nav-item">
                                <a class="nav-link active btn btn-primary" aria-current="page" href="{{route('registrations.create')}}">Register</a>
                                </li>
                            </ul>
                       

                            <h3 class="btn btn-secondary mt-3">College Students </h3>

                </div>
            </div>

        
                    <table class="table mt-2">
                        <thead>
                            <tr>
                                
                                <td><b>ID</b></td>
                                <td><b>Last Name</b></td>
                                <td><b>First Name</b></td>
                                <td><b>Year Level</b></td>
                                <td><b>Age</b></td>
                                <td><b>Birthday</b></td>
                                <td><b>Sex</b></td>
                                <td><b>Course</b></td>
                                <td><b>Edit</b></td>
                                <td><b>Delete</b></td>
                               
                                
                            </tr> 
                        </thead>
                        <tbody>
                            
                            @foreach ($registrations as $registration)
                            
                            <tr>
                                <td>{{$registration->id}}</td>
                                <td>{{$registration->lastname}}</td> 
                                <td>{{$registration->firstname}}</td> 
                                <td>{{$registration->year_level}}</td> 
                                <td>{{$registration->age}}</td> 
                                <td>{{$registration->birthday}}</td> 
                                <td>{{$registration->sex}}</td> 
                                <td>{{$registration->course}}</td> 
                               
                                
    
                                </td>
                                <div class="image pt-6">
                                    <td><a href="{{route('registrations.edit', $registration->id)}}"><center><img src="images/edit2.png" width=" 30px" height="20 px"></center></a></td>
                                </div>
                                
                                <td><a href="#" onclick="return confirm('Delete {{$registration->lastname}} {{$registration->firstname}}?');">
                                    <form action="{{route('registrations.destroy', $registration->id)}}" method="post">
                                        @method('DELETE')
                                        @csrf
                                        <button type=submit class= "btn btn-light"><center><img src="images/del.png" width=" 20px" height="20 px"></center></button>
                                    </form>
                                    </a></td>
                              
                            </tr>  
                            @endforeach
                        </tbody>
                    </table>
                    <a href="#" class=" nav-link active btn btn-secondary justify-content-end ">Back to top</a></a>	
@endsection