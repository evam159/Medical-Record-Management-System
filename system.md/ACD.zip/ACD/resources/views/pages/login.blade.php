@extends('layouts.master')

@section('title')
    Log In
@stop
@section('content')

<div class="container">
    <div class="pt-5">
        <div class="row">
            <div class="card border-dark col-md-4 offset-md-4 mt-6"><center>
                <h3 class="card border-light bg-light">ACD Clinic Admin</h3>
                <img src="images/acd.png" width=" 220px" height="200 px"></a>	</center>
                <div class="card border-light bg-light pt-4" style="width: 15 rem;">      

                <form action="{{route('login')}}" method="post">
                    <div class="form-group col-md-7 offset-md-2 pt-4">
                        Username <input type="text" name="username" id="" class="form-control">
                    </div>

                    <div class="form-group col-md-7 offset-md-2 mt-3">
                        Password <input type="password" name="password" id="" class="form-control">
                    </div>
                    <div class="form-group col-md-7 offset-md-2 mt-3">
                        <input type="submit" value="Login " class="btn btn-primary mt-2 form-control ">
                    </div>
                    <div class="form-group col-md-7 offset-md-1 mt-3"></div>
                    
                	    @csrf
                </form>
                @if ($errors->any())
                   <div class="alert alert-danger" role="alert">
                        {{$errors->first()}}
                    </div>
                 @endif
           
                
            </div>
            <div class="form-group col-md-7 offset-md-1 mt-3"></div>
        </div>
     </div>
</div>

@stop
@section('scripts')
<script>
    $('document').ready(function(){
        @if ($errors->any())
        $(".alert").fadeIn(500).delay(3000).fadeOut(500);   
        @endif 
    })
</script>
    
@stop