@extends('layouts.master')

@section('title')
    Nurse Register
@endsection

@section('content')

<div class="container border border-dark mt-5 pt-4">
    <div class="container">
        <nav class="navbar-light">
            <span class="navbar-brand mb-0 h1"><b>New Doctor</b></span>   
        </nav>
</div>
        
            <form action="{{route('nurses.store')}}" method="post">
                @csrf
                @method('post')
                    <div class="col-md-7 offset-md-3 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 40rem;">
                                <div class="card-body center">

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Id No.</b></label required>
                                        <input type="text" class="form-control" name ="id_no">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>Last Name</b></label required>
                                        <input type="text" class="form-control" name ="lastname">
                                    </div>

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>First Name</b></label required>
                                        <input type="text" class="form-control" name ="firstname">
                                    </div>
                                        
                                        <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                            <label class="form-group mb-4"><b>Sex</b></label required><br>
                                            <input type="radio" class="form-control">
                                            <input type="radio" name="sex" value="male"> Male<br>
                                            <input type="radio" name="sex" value="female"> Female<br>     
                                        </div>

                                    <div class="pt-4">
                                        <div class="row">
                                            <div class=" col-md-3 offset-md-3">
                                                <input type="submit" value="Create" class="btn btn-success">
                                            </div>
                                                <div class=" col-md-5">
                                                    <a href="{{route('nurses.index')}}" id="cancel" name="cancel" class="btn btn-primary">Cancel</a>
                                                   
                                            	</div>
                                        </div>
                                    </div>            
                                </div>
                            </div> 
                        </div>    
                    </div>
                    <div class="pt-5"></div> 
            </form>
    </div>
      
</div>
</div>        

@endsection
